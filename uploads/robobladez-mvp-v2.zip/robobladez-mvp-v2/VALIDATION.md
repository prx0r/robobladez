# Validation Report — RoboBladez MVP v2

## Status

- Unit/invariant tests: PASS
- Python compileall: PASS
- 250-seed audit: PASS
- Fresh end-to-end demo: PASS

## Unit tests

```text

Spreadsheet runtime warmup failed during python startup
Traceback (most recent call last):
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/spreadsheet_warmup.py", line 720, in _warm_feature_flows
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/spreadsheet_warmup.py", line 704, in _warm_collaboration_flows
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/generated/interface/models.py", line 32317, in hydrate_crdt_from_proto
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/rpc/remote.py", line 749, in __call__
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/rpc/client.py", line 150, in call
artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.
test_analysis_separates_projection (test_engine.EngineTests.test_analysis_separates_projection) ... ok
test_exact_determinism (test_engine.EngineTests.test_exact_determinism) ... ok
test_invalid_specs_rejected (test_engine.EngineTests.test_invalid_specs_rejected) ... ok
test_no_nan_many_seeds (test_engine.EngineTests.test_no_nan_many_seeds) ... ok
test_policy_commitment_config_sensitive (test_engine.EngineTests.test_policy_commitment_config_sensitive) ... ok
test_replay_digest_detects_tamper (test_engine.EngineTests.test_replay_digest_detects_tamper) ... ok
test_role_symmetry_for_counter_vs_aggressive (test_engine.EngineTests.test_role_symmetry_for_counter_vs_aggressive) ... ok
test_seed_changes_canon (test_engine.EngineTests.test_seed_changes_canon) ... ok
test_tie_is_not_awarded (test_engine.EngineTests.test_tie_is_not_awarded) ... ok
test_passive_energy_does_not_increase (test_physics.PhysicsTests.test_passive_energy_does_not_increase) ... ok
test_spin_decays_passively (test_physics.PhysicsTests.test_spin_decays_passively) ... ok

----------------------------------------------------------------------
Ran 11 tests in 1.607s

OK

```

## 250-seed audit

```json
{
  "numerical_fuzz_seeds": 250,
  "deterministic_exact": true,
  "digest_valid_matches": 250,
  "finite_rounds": 750,
  "passive_energy_initial": 10.84252487852812,
  "passive_energy_final": 7.580286020350442,
  "passive_energy_nonincreasing": true,
  "gameplay_sample": {
    "counter_vs_aggressive": {
      "matches": 10,
      "winners": {
        "draw": 3,
        "left": 7
      },
      "round_reasons": {
        "time_draw": 17,
        "ring_out": 11
      }
    },
    "aggressive_vs_counter": {
      "matches": 10,
      "winners": {
        "right": 8,
        "draw": 2
      },
      "round_reasons": {
        "ring_out": 14,
        "time_draw": 12
      }
    },
    "center_vs_aggressive": {
      "matches": 10,
      "winners": {
        "draw": 10
      },
      "round_reasons": {
        "time_draw": 30
      }
    },
    "aggressive_vs_aggressive": {
      "matches": 10,
      "winners": {
        "draw": 10
      },
      "round_reasons": {
        "time_draw": 30
      }
    }
  },
  "interpretation": {
    "numerical": "PASS if deterministic, all digests valid, no non-finite exception, passive energy non-increasing",
    "gameplay": "Sanity only. v2 does NOT claim balanced or non-transitive strategy; those are M1 exit criteria."
  }
}

```

## Fresh end-to-end demo

```json
{
  "mechanical_baseline_winner": null,
  "strategic_winner": "boris",
  "match_id": "0b416cb00ddcb0336a82",
  "replay_digest": "a2be49a260535a5b0f29b44a1d31d70164a47c59c0faa1cfd7994693ba294ed3",
  "canon_matches": 1
}

```

## Peer-review conclusion

v2 is fit to serve as the **M0/M1 architectural foundation**. The deterministic competition
constitution, replay integrity, policy commitments, match semantics, physical-state model, and
media boundary are now explicit and testable.

It is **not yet a finished game balance**. Current simple policy matchups show that some pairs
remain draw-heavy. Strategic diversity and non-transitivity are explicit M1 exit criteria before
RL, public submissions, or cinematic production expand the scope.
