import argparse,json
from .demo import run_demo
from .audit import run_audit

def main():
    p=argparse.ArgumentParser(prog="robobladez")
    sp=p.add_subparsers(dest="cmd",required=True)
    d=sp.add_parser("demo"); d.add_argument("--out",default="./out")
    a=sp.add_parser("audit"); a.add_argument("--seeds",type=int,default=250)
    x=p.parse_args()
    if x.cmd=="demo": print(json.dumps(run_demo(x.out),indent=2))
    else: print(json.dumps(run_audit(x.seeds),indent=2))
