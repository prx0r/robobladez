from itertools import combinations
from .model import ArenaSpec,BladeSpec
from .engine import run_match

def round_robin(entries,seed=1000,rounds=3):
    arena=ArenaSpec()
    pts={spec.id:0 for spec,_ in entries}
    matches=[]
    for i,((sa,pa),(sb,pb)) in enumerate(combinations(entries,2)):
        m=run_match(seed+i*100003,arena,sa,sb,pa,pb,rounds)
        matches.append(m)
        if m.winner:
            pts[m.winner]+=3
        else:
            pts[sa.id]+=1; pts[sb.id]+=1
    return matches,sorted(pts.items(),key=lambda kv:(-kv[1],kv[0]))
