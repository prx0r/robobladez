# RoboBladez MVP v2

A deterministic AI-vs-AI spinning-top competition engine whose canonical match history can
later be rendered as a serialized LTX show.

This version is deliberately narrower and more rigorous than v1.

## Product thesis

**The game is real; the show is a reconstruction of the game.**

```text
immutable body + arena + committed policies + seed + engine version
                              ↓
                    deterministic simulation
                              ↓
                  canonical replay + events
                              ↓
                    history + analysis
                              ↓
                 narrative / shot projection
                              ↓
                         LTX / media
```

## What v2 proves

- deterministic seeded simulation
- physically motivated planar spinning-top dynamics
- mass, radius, moment of inertia, angular spin, spin drag
- disk-disk contact impulses with tangential friction and spin coupling
- bowl restoring force and open rim / ring-out
- spin-out and burst terminal conditions
- simultaneous policy decisions
- policy code/config fingerprints + sealed commitments
- mechanical baseline mode
- best-of-N with correct draw/tie handling
- canonical replay digest
- event log
- raw behavioral phenotype metrics
- *separate* narrative daimon projection
- SQLite canon store
- round-robin league
- deterministic story + LTX shot specs
- stress/audit harness
- unit/invariant tests

## What v2 explicitly does NOT claim

This is **not** a validated real-world Beyblade simulator.

It is a deterministic, physically motivated 2D RoboBlade game kernel. Its contact mechanics are
real rigid-disk impulse mechanics, but the stadium is a planar bowl approximation and control
forces are fictional actuators. A later PyBullet or custom 3D backend can replace the kernel
without changing the match/canon contracts.

That boundary is intentional.

## Quick start

Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .

robobladez demo --out ./out
robobladez audit --seeds 250
```

Tests:

```bash
python -m unittest discover -s tests -v
```

## Read first

1. `docs/PEER_REVIEW_V1.md`
2. `docs/CONSTITUTION.md`
3. `docs/PHYSICS_SCOPE.md`
4. `docs/GAMEPLAY.md`
5. `docs/BUILD_NEXT.md`
