# Required Test Additions

## P0 regression tests

### Salience
- decisive ordinary match does NOT automatically increment salience for both agents
- upset detector assigns salience only to supported agent
- one match cannot create multiple career-salience credits for same event ID

### Signature
- one winning match cannot confirm a signature
- repeated window within one match does not satisfy cross-match recurrence
- same pattern across two losses is not confirmed
- same pattern across >=2 wins and >=2 match IDs can become confirmed
- signature evidence is stable under replay ordering

### Transactionality
- swapping evolve order A/B produces identical final agent states
- each agent's opponent model observes the same designated snapshot epoch

### Reincarnation
- invalid state target rejected
- unreachable state detected
- transition/action count respects compute class
- non-finite constants rejected
- illegal observation/action rejected
- manifest normalization is byte stable
- AST hash changes on any execution-affecting field
- AST hash does NOT change on purely narrative metadata if narrative metadata is outside executable manifest
- same manifest + same seed produces identical replay digest
- controller cannot access wall clock / filesystem / network

### Seed protocol
- seed unavailable to authoring context
- seed derivation verifies after reveal
- organizer cannot change seed without invalidating precommit
- either competitor cannot choose seed after observing opponent manifest

## P1 property tests

- affinities sum to 1 ± epsilon after arbitrary update sequences
- stage never regresses
- stage cannot advance without every executable gate
- duplicate evidence IDs do not double-count stage requirements
- interaction events are immutable
- every match object references existing agent/body/reincarnation versions
- historical replay derives identical AgentVersion N+1 from same AgentVersion N + canonical events

## Fuzz targets

- Reincarnation AST parser/validator
- Action clamp / NaN / +/-inf
- malformed replay input
- enormous transition graph
- cyclic graph with no terminal/fallback path
- zero-state controller
- maximum allowed memory
