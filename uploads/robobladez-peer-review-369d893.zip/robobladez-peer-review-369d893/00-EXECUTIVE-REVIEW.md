# RoboBladez Peer Review — Commit 369d893

Commit reviewed: `369d893`  
Base: `8b90a08`  
Scope: 42 changed files, +7,358 / -38 lines.

## Verdict

**Conceptual architecture: APPROVE. Runtime correctness: REQUEST CHANGES before treating rm7 as implemented.**

The commit makes a major architectural improvement: Reincarnation is now correctly distinguished from persistent Agent identity, Talisman/body, and Daimon. The bounded-DSL + compile/validate/lock model is the right long-term competitive architecture.

However, several runtime paths currently contradict the new mechanism documents. The most important issue is not that the design is too ambitious; it is that some analytics counters make the system *look* structurally emergent while still being almost linear progression in practice.

### Highest priority corrections

1. **Daimon salience inflation**
   `run_battle()` passes `salient=bool(match.winner)` to BOTH competitors. Every decisive match therefore increments `salient_events` for the winner and loser alike. This defeats the intended "rare career-defining event" requirement.

2. **Signature inflation**
   `_has_signature()` constructs a fresh detector for a single match and overrides `min_occurrences=1`. This directly contradicts `SIGNATURE-MOVES.md`, which says a signature requires repeated statistical support and defaults to `min_occurrences=2`. Repeated windows *inside one match* can therefore count as a career signature.

3. **Structural Daimon requirements are only partially encoded**
   Documentation requires stable phenotype, stable affinity, behavioral coherence, Agent↔Daimon coordination, and rare career conditions at higher stages. Runtime `STAGE_REQ` checks only `(battle_count, signature_candidates, salient_events)`. The prose requirements are not executable invariants yet.

4. **Reincarnation compiler is specification-only**
   `REINCARNATION-COMPILER.md` describes AST → validator → normalization → hash → compiler → BattleExecutable. Current battle runtime still selects pre-written Python `Policy` objects from `POLICY_ZOO`; there is no `ReincarnationManifest`, DSL AST, validator, compiler, compute class, lineage, or executable artifact in runtime.

5. **Seed commitment semantics need one constitutional answer**
   The new compiler doc says reincarnation is bound to `(agent_version, opponent_version, seed)`. If the policy is authored after seeing the exact match seed, deterministic physics becomes partially pre-solvable; if authored before seeing the seed, it cannot be bound to an unrevealed seed in the way currently stated. Define explicit seed-commit timing.

6. **Sequential post-match mutation creates asymmetry**
   Boris is evolved first using Morty's pre-update Daimon. Morty is evolved second using Boris's already-updated Daimon. Opponent models should observe immutable PRE-MATCH or POST-MATCH snapshots consistently.

## Recommendation

Keep `369d893`. Do not roll it back. Treat it as the **mechanism-contract commit** and follow with a focused rm8 implementation-hardening commit that makes runtime obey the mechanism corpus.
