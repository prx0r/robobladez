# Detailed Architectural Review

## 1. The five-actor model is a real improvement

The separation

`Human != Agent != Daimon != Talisman != BattleAvatar/Reincarnation`

is materially better than earlier versions. It removes three chronic ambiguities:

- identity versus embodiment,
- persistent cognition versus match-specific executable strategy,
- human mentoring versus direct control.

The strongest refinement is to use **Reincarnation** for the executable mechanism and **Battle Avatar** for presentation. Keep that distinction.

### Canonical object recommendation

Use six explicit IDs in every match record:

```text
human_id
agent_id
agent_version_id
daimon_version_id
talisman_version_id
reincarnation_id
```

The match should never infer one from another.

---

## 2. Reincarnation should become the center of the runtime

The new document is the right architecture but current runtime stops one layer early.

Current:
```text
Agent -> Strategist.choose() -> one prewritten Python Policy -> commitment -> engine
```

Target:
```text
AgentVersion
 + OpponentModelSnapshot
 + MechanicalReport
 + Ruleset
 + Arena
        ↓
ReincarnationAuthor
        ↓
ReincarnationAST
        ↓
validate
        ↓
normalize
        ↓
commit canonical manifest
        ↓
compile/interpreter
        ↓
BattleExecutable
        ↓
engine
```

### Minimal RBZ-RC-1 implementation

Do not begin with arbitrary code generation. Implement:

```python
ReincarnationManifest
ReincarnationState
Transition
Condition
ActionExpr
MemorySlot
ComputeClass
```

Interpreter is enough for MVP; "compile" can initially mean canonical AST -> validated executable state machine.

Critical property:
`canonical_ast_bytes` must be the object that is hashed and later revealed.

---

## 3. Fix the seed protocol before adding smarter agents

A deterministic sport needs uncertainty about initial conditions *and* replayability.

Recommended protocol:

```text
1. Publish match_challenge:
   arena_version
   body versions
   opponent versions
   ruleset
   seed_commitment_scheme

2. Agents author reincarnations without exact simulation seed.

3. Both submit:
   reincarnation_commitment

4. League closes strategy phase.

5. Match seed is generated/derived.

6. Engine executes:
   engine_version
   arena_version
   body versions
   reincarnation manifests
   seed

7. Post-match reveal verifies commitments.
```

Possible deterministic seed derivation:
```text
seed = H(server_nonce || commitment_A || commitment_B || match_challenge_id)
```
where `server_nonce` was committed by league before strategy submission and revealed afterward.

This prevents the organizer changing the seed after seeing policies while preventing agents pre-solving the exact launch.

---

## 4. Daimon emergence needs event semantics, not counters

Current counters are a good scaffold but are not sufficient to justify the labels in the docs.

### Replace `salient: bool` with typed canonical events

```text
UPSET
TITLE_WIN
TITLE_LOSS
STREAK_STARTED
STREAK_BROKEN
COMEBACK
RIVALRY_TURN
SIGNATURE_CONFIRMED
META_INNOVATION
REINCARNATION_BREAKTHROUGH
```

Each event should include evidence:
```json
{
  "type": "UPSET",
  "agent_id": "boris",
  "match_id": "...",
  "metric": "pre_match_win_probability",
  "before": 0.18,
  "threshold": 0.30
}
```

Then Daimon stages consume evidence IDs, not booleans.

### Stability gates

Suggested executable gates:

- `phenotype_stability`: cosine similarity / distance of behavior vectors over trailing K matches.
- `affinity_stability`: max elemental-affinity drift over trailing K.
- `cross_opponent_support`: signatures reproduced against >= N opponent IDs.
- `coordination_score`: only once Daimon becomes causal in a later ruleset; until then do not claim Agent↔Daimon coordination.
- `career_condition_count`: count typed salience events with unique match IDs.

Important contradiction:
Current docs say Daimon is **non-causal**, but DEVELOPED requires "successful Agent↔Daimon coordination." Coordination cannot be measured if the Daimon never influences strategy. Either:
1. keep Daimon non-causal and remove coordination from stage requirement, or
2. later allow Daimon to participate in *pre-match authoring* while remaining forbidden per tick.

Option 2 is more interesting and compatible with sealed competition.

---

## 5. Signature moves must be career-level objects

A signature is not a repeated 5-frame window in one match.

Promote only when:
```text
same/clustered pattern
+ >= 2 distinct matches
+ >= 2 wins
+ preferably >= 2 opponents
+ positive outcome lift versus baseline
```

Better still:
```text
P(win | pattern occurs) - P(win | pattern absent)
```
with minimum support.

Persist:
```text
SignatureCandidate
candidate_id
agent_id
pattern_cluster
match_ids
opponent_ids
occurrences
wins
outcome_lift
status: candidate|confirmed|retired
```

Only `confirmed` signatures should count toward structural Daimon evolution.

---

## 6. Post-match updates should be transactional

Do not mutate A, then let B observe changed A.

Correct sequence:

```text
preA = snapshot(A)
preB = snapshot(B)

analysis = analyze(match)

reflectionA = derive(preA, preB, match, analysis)
reflectionB = derive(preB, preA, match, analysis)

deltaA = project_updates(...)
deltaB = project_updates(...)

commit both deltas atomically
```

This also makes historical replay of character evolution deterministic.

---

## 7. Human interaction has the right philosophy but weak data guarantees

Current event:
```text
type, human, agent, content, timestamp, agent_response, adopted
```

Recommended:
```text
event_id
schema_version
occurred_at
recorded_at
human_id
agent_id
interaction_type
content_hash
content
agent_response
adoption_status: pending|rejected|accepted|partially_accepted
adopted_into_agent_version
adopted_into_reincarnation_id
supersedes_event_id
```

This lets the show truthfully say:
"Tom suggested X; Boris rejected it" or
"Boris accepted it and R028 incorporated transition T14."

Without that link, `adopted=True` is narrative assertion rather than provenance.

---

## 8. Typed namespaces are now mandatory

The project has crossed the point where strings named `id` are safe.

At minimum introduce wrappers or field names:
```text
AgentId
BodyId
MatchId
ReincarnationId
PolicyId
DaimonId
```

Current battle/reflection paths frequently pass blade IDs into fields/functions that semantically talk about agents. This is survivable with two demo bots but will become a canon corruption source once one agent changes bodies or uses multiple reincarnations.

---

## 9. Mechanism corpus quality

The template is excellent: purpose, canonical status, inputs/state, transitions, invariants, visibility, determinism, failures, telemetry, versioning, security, tests, non-goals.

The next improvement should be **machine-checkable contract coverage**.

Add `docs/mechanisms/index.yaml`:
```yaml
- id: REINCARNATION_COMPILER
  status: SPECIFIED
  implementation:
    - src/robobladez/reincarnation.py
  tests:
    - tests/test_reincarnation.py
  canonical_status: [GAMEPLAY, INFRA]
  version: RBZ-RC-1
```

Status enum:
```text
IDEA
SPECIFIED
SCAFFOLDED
IMPLEMENTED
VERIFIED
```

This prevents prose from silently outrunning runtime.

---

## 10. What I would build next

One focused rm8:

**"Make emergence claims evidence-bearing and reincarnation executable."**

Order:
1. Typed IDs / immutable snapshots.
2. Fix salience and signature false positives.
3. Transactional post-match evolution.
4. Implement RBZ-RC-1 AST + validator + interpreter.
5. Commit exact canonical AST, not Python source.
6. Add seed commit/reveal protocol.
7. Persist reincarnation lineage.
8. Mechanism implementation index.
9. CI + property/fuzz tests.

Do not add RL, quantum mechanics, GNNs, or larger LLMs during rm8. The current bottleneck is constitutional correctness.
