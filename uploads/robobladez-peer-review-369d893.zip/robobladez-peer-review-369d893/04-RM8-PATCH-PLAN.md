# rm8 Proposed Patch Plan

## Commit A — Evidence correctness
- Replace `salient: bool` with `list[SalienceEvidence]`.
- Remove `_has_signature(... min_occurrences=1)`.
- Create persistent `SignatureRegistry`.
- Add cross-match/cross-opponent support.
- Snapshot both agents before post-match derivation.
- Apply both updates transactionally.

## Commit B — Typed identity + provenance
- Introduce explicit agent/body/reincarnation IDs.
- Refactor BattleOutcome maps to key by agent/reincarnation ID.
- Make HumanInteractionEvent immutable and hash-addressed.
- Link accepted advice to resulting AgentVersion/Reincarnation.

## Commit C — RBZ-RC-1 executable MVP
Files:
```text
src/robobladez/reincarnation/
    schema.py
    normalize.py
    validate.py
    runtime.py
    commitment.py
    lineage.py
```

Start with an interpreter, not native code generation.

Example bounded AST:
```json
{
  "format": "RBZ-RC-1",
  "agent_version": "boris@27",
  "target_match": "S01-M028",
  "compute_class": "C1",
  "memory": [{"name":"pressure_seen","type":"u8","initial":0}],
  "states": [
    {"id":"observe","transitions":[
      {"if":{"lt":["distance",0.12]},"to":"counter"},
      {"else":true,"to":"orbit"}
    ]},
    {"id":"counter","action":{"radial":0.3,"tangential":0.7,"boost":0.6}},
    {"id":"orbit","action":{"radial":0.1,"tangential":0.8,"boost":0.3}}
  ],
  "initial_state":"observe"
}
```

## Commit D — Seed + commit/reveal
- Introduce MatchChallenge.
- Policies commit before final seed reveal.
- Canon stores organizer seed commitment and reveal.
- Final match execution tuple:
```text
engine_version
ruleset_version
arena_version
body_A_version
body_B_version
reincarnation_A_hash
reincarnation_B_hash
seed
```

## Commit E — Mechanism coverage registry + CI
- `docs/mechanisms/index.yaml`
- implementation status for every mechanism
- GitHub Actions:
  - unit
  - deterministic replay
  - contract/invariant
  - fuzz smoke
