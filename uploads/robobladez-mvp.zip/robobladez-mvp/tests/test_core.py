import unittest, json
from robobladez.model import BladeSpec, ArenaSpec
from robobladez.policy import AggressivePolicy, CounterPolicy, commitment
from robobladez.engine import run_match
from robobladez.analysis import analyze

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.a = BladeSpec("a")
        self.b = BladeSpec("b", mass=0.95)
        self.arena = ArenaSpec(max_seconds=3.0)
        self.pa = CounterPolicy()
        self.pb = AggressivePolicy()

    def test_determinism(self):
        m1 = run_match(123, self.arena, self.a,self.b,self.pa,self.pb,3)
        m2 = run_match(123, self.arena, self.a,self.b,self.pa,self.pb,3)
        self.assertEqual(m1.to_dict(), m2.to_dict())

    def test_seed_changes_replay(self):
        m1 = run_match(123, self.arena, self.a,self.b,self.pa,self.pb,3)
        m2 = run_match(124, self.arena, self.a,self.b,self.pa,self.pb,3)
        self.assertNotEqual(m1.to_dict(), m2.to_dict())

    def test_policy_commitment(self):
        c1 = commitment(self.pa, "match-1")
        c2 = commitment(self.pa, "match-1")
        c3 = commitment(self.pa, "match-2")
        self.assertEqual(c1,c2)
        self.assertNotEqual(c1,c3)

    def test_analysis(self):
        m = run_match(123, self.arena, self.a,self.b,self.pa,self.pb,3)
        a = analyze(m)
        self.assertEqual(set(a["a"]["affinities"]), {"earth","water","fire","air","aether"})
        self.assertAlmostEqual(sum(a["a"]["affinities"].values()), 1.0)

if __name__ == "__main__":
    unittest.main()
