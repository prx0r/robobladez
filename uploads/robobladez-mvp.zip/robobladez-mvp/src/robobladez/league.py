from __future__ import annotations
from itertools import combinations
from .engine import run_match
from .model import ArenaSpec, BladeSpec
from .policy import Policy

def round_robin(entries: list[tuple[BladeSpec,Policy]], seed: int = 1000, rounds: int = 3):
    arena = ArenaSpec()
    results = []
    standings = {spec.id:0 for spec,_ in entries}
    for i, ((sa,pa),(sb,pb)) in enumerate(combinations(entries,2)):
        m = run_match(seed+i*10000, arena, sa,sb,pa,pb,rounds)
        results.append(m)
        if m.winner:
            standings[m.winner] += 3
    return results, sorted(standings.items(), key=lambda x:(-x[1],x[0]))
