from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any
import math

@dataclass(frozen=True)
class Vec2:
    x: float
    y: float

    def __add__(self, other: "Vec2") -> "Vec2":
        return Vec2(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "Vec2") -> "Vec2":
        return Vec2(self.x - other.x, self.y - other.y)

    def __mul__(self, k: float) -> "Vec2":
        return Vec2(self.x * k, self.y * k)

    def norm(self) -> float:
        return math.hypot(self.x, self.y)

    def unit(self) -> "Vec2":
        n = self.norm()
        return Vec2(0.0, 0.0) if n == 0 else Vec2(self.x / n, self.y / n)

@dataclass(frozen=True)
class BladeSpec:
    id: str
    mass: float = 1.0
    radius: float = 0.10
    friction: float = 0.018
    restitution: float = 0.82
    thrust: float = 0.55
    energy: float = 100.0
    integrity: float = 100.0

@dataclass(frozen=True)
class ArenaSpec:
    id: str = "standard-bowl"
    radius: float = 3.0
    dt: float = 1 / 60
    max_seconds: float = 45.0
    drag: float = 0.010
    boundary_restitution: float = 0.65

@dataclass(frozen=True)
class Action:
    radial: float = 0.0       # -1 out, +1 in
    tangential: float = 0.0   # -1 clockwise, +1 ccw
    boost: float = 0.0        # 0..1

    def clamped(self) -> "Action":
        c = lambda v: max(-1.0, min(1.0, v))
        return Action(c(self.radial), c(self.tangential), max(0.0, min(1.0, self.boost)))

@dataclass
class BladeState:
    id: str
    pos: Vec2
    vel: Vec2
    energy: float
    integrity: float
    active: bool = True

@dataclass(frozen=True)
class Observation:
    tick: int
    round_no: int
    self_pos: Vec2
    self_vel: Vec2
    self_energy: float
    self_integrity: float
    opponent_pos: Vec2
    opponent_vel: Vec2
    opponent_energy: float
    opponent_integrity: float
    arena_radius: float
    prior_round_winners: tuple[str, ...] = ()

@dataclass
class Event:
    tick: int
    t: float
    type: str
    actor: str | None = None
    target: str | None = None
    importance: float = 0.0
    data: dict[str, Any] = field(default_factory=dict)

@dataclass
class Frame:
    tick: int
    t: float
    states: dict[str, dict[str, Any]]
    actions: dict[str, dict[str, float]]

@dataclass
class RoundResult:
    round_no: int
    winner: str | None
    reason: str
    frames: list[Frame]
    events: list[Event]

@dataclass
class MatchResult:
    match_id: str
    engine_version: str
    seed: int
    arena: dict[str, Any]
    blades: dict[str, dict[str, Any]]
    policy_commitments: dict[str, str]
    rounds: list[RoundResult]
    winner: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
