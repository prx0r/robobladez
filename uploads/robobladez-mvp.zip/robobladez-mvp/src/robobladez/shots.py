from __future__ import annotations

def compile_shots(episode: dict) -> dict:
    shots = [{
        "id": "S001",
        "purpose": "establish_arena",
        "duration_s": 5,
        "camera": "wide_orbit",
        "prompt": "Establish the RoboBladez arena and both competitors before the match.",
        "canon_constraints": ["both competitors visible", "no outcome implication"],
    }]
    idx = 2
    for beat in episode["beats"][:10]:
        shots.append({
            "id": f"S{idx:03d}",
            "purpose": beat["kind"],
            "duration_s": 5 if beat["importance"] < 0.9 else 6,
            "camera": "tracking_close" if beat["kind"] != "round_result" else "result_wide",
            "prompt": f"Visualize canonical beat: {beat['summary']}. Preserve event order and competitor identity.",
            "canon_constraints": [
                f"round={beat['round_no']}",
                f"event={beat['kind']}",
                "do not invent a different result",
            ],
        })
        idx += 1
    return {
        "episode_id": episode["episode_id"],
        "renderer_target": "LTX-2 / ComfyUI",
        "shots": shots,
    }
