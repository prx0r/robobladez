from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Protocol
import hashlib, json, math
from .model import Action, Observation

class Policy(Protocol):
    id: str
    def decide(self, obs: Observation) -> Action: ...
    def public_config(self) -> dict: ...

def commitment(policy: Policy, match_nonce: str) -> str:
    payload = {
        "policy_id": policy.id,
        "config": policy.public_config(),
        "match_nonce": match_nonce,
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(canonical).hexdigest()

@dataclass
class CenterControlPolicy:
    id: str = "center-control-v1"
    aggression: float = 0.25
    orbit: float = 0.20

    def public_config(self) -> dict:
        return asdict(self)

    def decide(self, obs: Observation) -> Action:
        d = math.hypot(obs.self_pos.x, obs.self_pos.y)
        radial = 0.9 if d > 0.8 else 0.15
        dx = obs.opponent_pos.x - obs.self_pos.x
        dy = obs.opponent_pos.y - obs.self_pos.y
        distance = math.hypot(dx, dy)
        boost = self.aggression if distance < 1.1 else 0.05
        return Action(radial=radial, tangential=self.orbit, boost=boost)

@dataclass
class AggressivePolicy:
    id: str = "aggressive-v1"
    charge: float = 0.95
    orbit: float = 0.05

    def public_config(self) -> dict:
        return asdict(self)

    def decide(self, obs: Observation) -> Action:
        # Radial is relative to arena center, so aggression is represented
        # mainly by boost + low orbiting rather than direct steering toward opponent.
        return Action(radial=0.10, tangential=self.orbit, boost=self.charge)

@dataclass
class CounterPolicy:
    id: str = "counter-v1"
    patience: float = 0.80
    punish_threshold: float = 0.9

    def public_config(self) -> dict:
        return asdict(self)

    def decide(self, obs: Observation) -> Action:
        opp_speed = math.hypot(obs.opponent_vel.x, obs.opponent_vel.y)
        distance = math.hypot(
            obs.opponent_pos.x - obs.self_pos.x,
            obs.opponent_pos.y - obs.self_pos.y,
        )
        if opp_speed > self.punish_threshold and distance < 1.3:
            return Action(radial=0.55, tangential=-0.65, boost=0.75)
        return Action(radial=0.55, tangential=0.25, boost=1.0 - self.patience)
