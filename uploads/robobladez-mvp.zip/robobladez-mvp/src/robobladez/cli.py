from __future__ import annotations
import argparse, json
from .demo import run_demo

def main():
    p = argparse.ArgumentParser(prog="robobladez")
    sub = p.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("demo", help="run deterministic Boris vs Morty demo")
    d.add_argument("--out", default="./out")
    args = p.parse_args()
    if args.cmd == "demo":
        print(json.dumps(run_demo(args.out), indent=2))

if __name__ == "__main__":
    main()
