from __future__ import annotations
from pathlib import Path
import json
from .model import BladeSpec, ArenaSpec
from .policy import CounterPolicy, AggressivePolicy
from .engine import run_match
from .replay import save_match
from .analysis import analyze
from .canon import CanonStore
from .story import compile_story
from .shots import compile_shots

def run_demo(out_dir: str | Path) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    boris = BladeSpec("boris", mass=1.05, radius=0.105, friction=0.017, thrust=0.52)
    morty = BladeSpec("morty", mass=0.95, radius=0.095, friction=0.020, thrust=0.60)
    arena = ArenaSpec()
    match = run_match(424242, arena, boris, morty, CounterPolicy(), AggressivePolicy(), rounds=5)
    save_match(match, out/"match.json")
    analysis = analyze(match)
    (out/"analysis.json").write_text(json.dumps(analysis, indent=2))
    episode = compile_story(match, analysis)
    (out/"episode.json").write_text(json.dumps(episode, indent=2))
    shots = compile_shots(episode)
    (out/"shots.json").write_text(json.dumps(shots, indent=2))
    store = CanonStore(out/"canon.sqlite3")
    store.save_match(match)
    return {"winner":match.winner,"match_id":match.match_id,"canon_matches":store.match_count()}
