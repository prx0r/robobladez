from __future__ import annotations
from dataclasses import dataclass, asdict
from .model import MatchResult

@dataclass
class StoryBeat:
    kind: str
    round_no: int
    t: float
    summary: str
    importance: float

def compile_story(match: MatchResult, analysis: dict) -> dict:
    beats: list[StoryBeat] = []
    for rnd in match.rounds:
        if rnd.events:
            top = sorted(rnd.events, key=lambda e:e.importance, reverse=True)[:2]
            for e in top:
                beats.append(StoryBeat(
                    kind=e.type,
                    round_no=rnd.round_no,
                    t=e.t,
                    summary=f"{e.actor or 'arena'}: {e.type}",
                    importance=e.importance
                ))
        beats.append(StoryBeat(
            kind="round_result",
            round_no=rnd.round_no,
            t=rnd.frames[-1].t if rnd.frames else 0.0,
            summary=f"Round {rnd.round_no}: {rnd.winner or 'draw'} ({rnd.reason})",
            importance=0.8,
        ))
    beats = sorted(beats, key=lambda b:(b.round_no,b.t))
    protagonists = {
        k: {
            "dominant_element": v["dominant_element"],
            "affinities": v["affinities"],
        } for k,v in analysis.items()
    }
    return {
        "episode_id": f"EP-{match.match_id}",
        "match_id": match.match_id,
        "winner": match.winner,
        "hook": f"A sealed-policy match resolved by deterministic simulation: {match.winner or 'draw'}.",
        "protagonists": protagonists,
        "beats": [asdict(b) for b in beats],
        "canon_rule": "Simulation outcome is immutable; dramatization may not change winner or event order.",
    }
