from __future__ import annotations
from dataclasses import asdict
import hashlib, math, random
from .model import *
from .policy import Policy, commitment

ENGINE_VERSION = "rbz-core-0.1.0"

def _hash_id(seed: int, a: str, b: str) -> str:
    return hashlib.sha256(f"{ENGINE_VERSION}:{seed}:{a}:{b}".encode()).hexdigest()[:16]

def _initial_state(spec: BladeSpec, angle: float, arena: ArenaSpec, spin_sign: float) -> BladeState:
    r = arena.radius * 0.43
    pos = Vec2(math.cos(angle) * r, math.sin(angle) * r)
    tangent = Vec2(-math.sin(angle), math.cos(angle))
    vel = tangent * (1.4 * spin_sign)
    return BladeState(spec.id, pos, vel, spec.energy, spec.integrity)

def _control_force(state: BladeState, action: Action, spec: BladeSpec) -> Vec2:
    a = action.clamped()
    rhat = state.pos.unit()
    that = Vec2(-rhat.y, rhat.x)
    strength = spec.thrust * (1.0 + 1.4 * a.boost)
    return rhat * (-a.radial * strength) + that * (a.tangential * strength)

def _step_boundary(state: BladeState, spec: BladeSpec, arena: ArenaSpec, events: list[Event], tick: int):
    d = state.pos.norm()
    limit = arena.radius - spec.radius
    if d <= limit:
        return
    n = state.pos.unit()
    overshoot = d - limit
    state.pos = state.pos - n * overshoot
    vn = state.vel.x * n.x + state.vel.y * n.y
    if vn > 0:
        state.vel = state.vel - n * ((1 + arena.boundary_restitution) * vn)
    state.integrity -= abs(vn) * 0.6
    events.append(Event(tick, tick * arena.dt, "boundary_contact", state.id, None,
                        min(1.0, abs(vn)/3), {"normal_speed": abs(vn)}))

def _resolve_collision(a: BladeState, b: BladeState, sa: BladeSpec, sb: BladeSpec,
                       arena: ArenaSpec, events: list[Event], tick: int):
    delta = b.pos - a.pos
    dist = delta.norm()
    min_dist = sa.radius + sb.radius
    if dist == 0 or dist >= min_dist:
        return
    n = delta.unit()
    rv = b.vel - a.vel
    rel = rv.x*n.x + rv.y*n.y
    if rel >= 0:
        return
    e = min(sa.restitution, sb.restitution)
    j = -(1+e)*rel / (1/sa.mass + 1/sb.mass)
    impulse = n * j
    a.vel = a.vel - impulse * (1/sa.mass)
    b.vel = b.vel + impulse * (1/sb.mass)
    penetration = min_dist - dist
    a.pos = a.pos - n*(penetration/2)
    b.pos = b.pos + n*(penetration/2)
    impact = abs(j)
    a.integrity -= impact * 0.25
    b.integrity -= impact * 0.25
    events.append(Event(tick, tick*arena.dt, "collision", a.id, b.id,
                        min(1.0, impact/4), {"impulse": impact}))

def _frame(tick, arena, states, actions):
    return Frame(
        tick=tick, t=tick*arena.dt,
        states={
            k: {
                "pos": {"x": v.pos.x, "y": v.pos.y},
                "vel": {"x": v.vel.x, "y": v.vel.y},
                "energy": v.energy,
                "integrity": v.integrity,
            } for k,v in states.items()
        },
        actions={k: asdict(v) for k,v in actions.items()}
    )

def run_round(round_no: int, seed: int, arena: ArenaSpec,
              spec_a: BladeSpec, spec_b: BladeSpec,
              policy_a: Policy, policy_b: Policy,
              prior_winners: tuple[str, ...]) -> RoundResult:
    rng = random.Random(seed)
    launch_jitter = rng.uniform(-0.05, 0.05)
    a = _initial_state(spec_a, 0.0 + launch_jitter, arena, 1.0)
    b = _initial_state(spec_b, math.pi - launch_jitter, arena, -1.0)
    states = {a.id: a, b.id: b}
    frames, events = [], []
    max_ticks = int(arena.max_seconds / arena.dt)

    for tick in range(max_ticks):
        oa = Observation(tick, round_no, a.pos, a.vel, a.energy, a.integrity,
                         b.pos, b.vel, b.energy, b.integrity, arena.radius, prior_winners)
        ob = Observation(tick, round_no, b.pos, b.vel, b.energy, b.integrity,
                         a.pos, a.vel, a.energy, a.integrity, arena.radius, prior_winners)

        # simultaneous commitment: both decisions are computed from the same pre-step state
        act_a = policy_a.decide(oa).clamped()
        act_b = policy_b.decide(ob).clamped()
        actions = {a.id: act_a, b.id: act_b}

        for state, spec, act in ((a,spec_a,act_a),(b,spec_b,act_b)):
            f = _control_force(state, act, spec)
            state.vel = state.vel + f * (arena.dt / spec.mass)
            state.energy = max(0.0, state.energy - act.boost * 0.035)
            drag = max(0.0, 1.0 - arena.drag - spec.friction)
            state.vel = state.vel * drag
            state.pos = state.pos + state.vel * arena.dt

        _resolve_collision(a,b,spec_a,spec_b,arena,events,tick)
        _step_boundary(a,spec_a,arena,events,tick)
        _step_boundary(b,spec_b,arena,events,tick)

        if tick % 3 == 0:
            frames.append(_frame(tick, arena, states, actions))

        for state in (a,b):
            if state.integrity <= 0:
                state.active = False

        if not a.active or not b.active:
            winner = b.id if not a.active and b.active else a.id if not b.active and a.active else None
            return RoundResult(round_no, winner, "integrity", frames, events)

    # time decision: integrity first, energy second
    score_a = a.integrity + 0.1*a.energy
    score_b = b.integrity + 0.1*b.energy
    winner = a.id if score_a > score_b else b.id if score_b > score_a else None
    return RoundResult(round_no, winner, "time", frames, events)

def run_match(seed: int, arena: ArenaSpec, spec_a: BladeSpec, spec_b: BladeSpec,
              policy_a: Policy, policy_b: Policy, rounds: int = 5) -> MatchResult:
    if rounds < 1 or rounds % 2 == 0:
        raise ValueError("rounds must be a positive odd number")
    match_id = _hash_id(seed, spec_a.id, spec_b.id)
    nonce = f"{match_id}:{seed}"
    commits = {
        spec_a.id: commitment(policy_a, nonce),
        spec_b.id: commitment(policy_b, nonce),
    }
    results = []
    wins = {spec_a.id: 0, spec_b.id: 0}
    needed = rounds//2 + 1
    priors: tuple[str,...] = ()
    for r in range(1, rounds+1):
        rr = run_round(r, seed + r*1009, arena, spec_a, spec_b, policy_a, policy_b, priors)
        results.append(rr)
        if rr.winner:
            wins[rr.winner] += 1
            priors = priors + (rr.winner,)
        if max(wins.values()) >= needed:
            break
    winner = max(wins, key=wins.get) if max(wins.values()) > 0 else None
    return MatchResult(
        match_id=match_id,
        engine_version=ENGINE_VERSION,
        seed=seed,
        arena=asdict(arena),
        blades={spec_a.id: asdict(spec_a), spec_b.id: asdict(spec_b)},
        policy_commitments=commits,
        rounds=results,
        winner=winner,
    )
