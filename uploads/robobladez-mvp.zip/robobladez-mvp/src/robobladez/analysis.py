from __future__ import annotations
from collections import defaultdict
import math
from .model import MatchResult

ELEMENTS = ("earth","water","fire","air","aether")

def analyze(match: MatchResult) -> dict:
    stats = {
        blade_id: defaultdict(float)
        for blade_id in match.blades
    }
    samples = {blade_id: 0 for blade_id in match.blades}

    for rnd in match.rounds:
        for frame in rnd.frames:
            ids = list(frame.states.keys())
            for blade_id in ids:
                s = frame.states[blade_id]
                a = frame.actions[blade_id]
                v = s["vel"]
                p = s["pos"]
                speed = math.hypot(v["x"], v["y"])
                radius = math.hypot(p["x"], p["y"])
                st = stats[blade_id]
                samples[blade_id] += 1
                st["speed_sum"] += speed
                st["center_control"] += 1.0 if radius < match.arena["radius"]*0.35 else 0.0
                st["boost_sum"] += a["boost"]
                st["radial_in"] += max(0.0, a["radial"])
                st["orbit"] += abs(a["tangential"])
        for event in rnd.events:
            if event.actor in stats:
                if event.type == "collision":
                    stats[event.actor]["collisions"] += 1
                if event.type == "boundary_contact":
                    stats[event.actor]["boundary_contacts"] += 1

    out = {}
    for blade_id, st in stats.items():
        n = max(1, samples[blade_id])
        avg_speed = st["speed_sum"]/n
        center = st["center_control"]/n
        boost = st["boost_sum"]/n
        orbit = st["orbit"]/n
        boundary = st["boundary_contacts"]/max(1, len(match.rounds))
        # Simple interpretable phenotype scores, intentionally not ML.
        earth = 0.50*center + 0.30*(1-boost) + 0.20*max(0,1-min(1,avg_speed/2))
        fire = 0.55*boost + 0.30*min(1,st["collisions"]/max(1,len(match.rounds)*4)) + 0.15*min(1,avg_speed/2)
        air = 0.55*min(1,avg_speed/2) + 0.30*orbit + 0.15*max(0,1-min(1,boundary))
        water = 0.45*orbit + 0.35*center + 0.20*(1-abs(0.5-boost)*2)
        aether = 0.45*min(1,boundary/4) + 0.30*orbit + 0.25*boost
        raw = {"earth":earth,"water":water,"fire":fire,"air":air,"aether":aether}
        total = sum(max(0,v) for v in raw.values()) or 1.0
        affinities = {k: max(0,v)/total for k,v in raw.items()}
        out[blade_id] = {
            "metrics": {
                "avg_speed": avg_speed,
                "center_control": center,
                "avg_boost": boost,
                "avg_orbit": orbit,
                "boundary_contacts_per_round": boundary,
                "collision_events": st["collisions"],
            },
            "affinities": affinities,
            "dominant_element": max(affinities, key=affinities.get),
        }
    return out
