from __future__ import annotations
import json, sqlite3
from pathlib import Path
from .model import MatchResult

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS matches (
  match_id TEXT PRIMARY KEY,
  engine_version TEXT NOT NULL,
  seed INTEGER NOT NULL,
  winner TEXT,
  payload_json TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS agent_snapshots (
  agent_id TEXT NOT NULL,
  version INTEGER NOT NULL,
  snapshot_json TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(agent_id, version)
);
"""

class CanonStore:
    def __init__(self, path: str | Path):
        self.path = str(path)
        self.db = sqlite3.connect(self.path)
        self.db.executescript(SCHEMA)
        self.db.commit()

    def save_match(self, match: MatchResult) -> None:
        self.db.execute(
            "INSERT OR REPLACE INTO matches(match_id,engine_version,seed,winner,payload_json) VALUES(?,?,?,?,?)",
            (match.match_id, match.engine_version, match.seed, match.winner, json.dumps(match.to_dict()))
        )
        self.db.commit()

    def save_agent_snapshot(self, agent_id: str, version: int, snapshot: dict) -> None:
        self.db.execute(
            "INSERT OR REPLACE INTO agent_snapshots(agent_id,version,snapshot_json) VALUES(?,?,?)",
            (agent_id, version, json.dumps(snapshot))
        )
        self.db.commit()

    def match_count(self) -> int:
        return self.db.execute("SELECT COUNT(*) FROM matches").fetchone()[0]
