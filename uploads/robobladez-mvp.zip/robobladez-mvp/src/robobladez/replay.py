from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import json
from .model import MatchResult

def save_match(match: MatchResult, path: str | Path) -> None:
    Path(path).write_text(json.dumps(match.to_dict(), indent=2), encoding="utf-8")

def load_match_dict(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))
