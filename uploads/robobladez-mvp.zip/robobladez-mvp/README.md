# RoboBladez MVP

A monolithic, deterministic AI-competition + canon + content compiler.

Core rule:

> The simulation decides what happened. The media layer decides how it is shown.

This repository is intentionally small enough to understand end-to-end. It is **not**
a microservice architecture and does not require RL, a graph database, a custom LLM,
or a cinematic renderer to prove the loop.

## What is implemented

- deterministic seeded 2D arena simulation
- configurable blade bodies
- simultaneous policy decisions
- sealed policy commitments
- best-of-N matches
- structured replay + event log
- behavior analysis
- emergent elemental/daimon affinity
- SQLite canon/history store
- round-robin league runner
- deterministic story beat extraction
- LTX-oriented shot-spec compiler
- tests for determinism and commitments

## The intended loop

```text
Agent + Body + Arena
        ↓
Mechanical / strategic match
        ↓
Canonical Replay
        ↓
Events + Analytics
        ↓
History / Daimon / Meta
        ↓
Story Beats
        ↓
Shot Specs
        ↓
LTX / ComfyUI (external)
```

## Quick start

Python 3.11+ recommended.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
robobladez demo --out ./out
```

Run tests:

```bash
python -m unittest discover -s tests -v
```

Outputs include:

```text
out/match.json
out/analysis.json
out/episode.json
out/shots.json
out/canon.sqlite3
```

## Architecture stance

The MVP uses a tiny deterministic 2D physics kernel so the rules and replay contract
can be validated immediately. A PyBullet backend is a planned adapter, not a dependency
of the core game contract.

The code is organized as a **modular monolith**:
one deployable Python application, clear internal module boundaries.

See:

- `docs/ARCHITECTURE.md`
- `docs/GAME_RULES.md`
- `docs/EVOLUTION.md`
- `docs/MEDIA_PIPELINE.md`
- `docs/EXTERNAL-INFRA.md`
- `docs/BUILD_ORDER.md`
